package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.Strings
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingCardElevated
import com.example.ui.theme.GamingDarkBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.GamingOrange
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.VpnRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileSettingsScreen(
  onNavigateToPremium: () -> Unit,
  onNavigateToAdmin: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userAccount by VpnRepository.userAccount.collectAsState()
  val language by VpnRepository.language.collectAsState()
  val killSwitch by VpnRepository.killSwitchEnabled.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Header
    Text(
      text = if (language == "bn") "প্রোফাইল ও সেটিংস" else "Profile & Settings",
      fontSize = 20.sp,
      fontWeight = FontWeight.Black,
      color = TextPrimary
    )
    Text(
      text = if (language == "bn") "অ্যাকাউন্ট স্ট্যাটাস ও ভিপিএন কনফিগারেশন" else "Account status & VPN configuration",
      fontSize = 12.sp,
      color = TextMuted
    )

    Spacer(modifier = Modifier.height(14.dp))

    // User Profile Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardElevated),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = Brush.linearGradient(
          if (userAccount.isPremium) listOf(GamingGold, GamingOrange)
          else listOf(GamingBorder, NeonGreen.copy(alpha = 0.3f))
        )
      )
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(CircleShape)
              .background(
                Brush.linearGradient(
                  if (userAccount.isPremium) listOf(GamingGold, GamingOrange)
                  else listOf(NeonGreen.copy(alpha = 0.2f), CyberCyan.copy(alpha = 0.2f))
                )
              )
              .border(
                2.dp,
                if (userAccount.isPremium) GamingGold else NeonGreen,
                CircleShape
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (userAccount.isPremium) Icons.Default.Star else Icons.Default.Person,
              contentDescription = "Avatar",
              tint = if (userAccount.isPremium) GamingDarkBg else NeonGreen,
              modifier = Modifier.size(28.dp)
            )
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = userAccount.username,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Spacer(modifier = Modifier.width(8.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (userAccount.isPremium) GamingGold else NeonGreen.copy(alpha = 0.15f))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = if (userAccount.isPremium) "VIP GAMER" else "FREE TIER",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Black,
                  color = if (userAccount.isPremium) GamingDarkBg else NeonGreen
                )
              }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = userAccount.email, fontSize = 12.sp, color = TextMuted)
          }
        }

        if (userAccount.isPremium) {
          Spacer(modifier = Modifier.height(10.dp))
          val expiry = userAccount.premiumExpiryDate?.let {
            SimpleDateFormat("dd MMMM, yyyy", Locale.getDefault()).format(Date(it))
          } ?: "30 Days Active"
          Text(
            text = if (language == "bn") "মেয়াদ শেষ হবে: $expiry" else "Expires on: $expiry",
            fontSize = 12.sp,
            color = GamingGold
          )
        } else {
          Spacer(modifier = Modifier.height(14.dp))
          Button(
            onClick = onNavigateToPremium,
            colors = ButtonDefaults.buttonColors(containerColor = GamingGold),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(40.dp)
          ) {
            Icon(imageVector = Icons.Default.Lock, contentDescription = "VIP", tint = GamingDarkBg, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = Strings.get("upgrade_premium", language),
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = GamingDarkBg
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // App Preferences Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GamingCardBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, GamingBorder)))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp)
      ) {
        // Language
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Language, contentDescription = "Lang", tint = CyberCyan, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (language == "bn") "অ্যাপের ভাষা" else "App Language",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = if (language == "bn") "বাংলা এবং ইংরেজি সহজে পরিবর্তন" else "Switch between Bengali and English",
                fontSize = 11.sp,
                color = TextMuted
              )
            }
          }

          Row {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (language == "bn") NeonGreen else GamingDarkBg)
                .clickable { VpnRepository.setLanguage("bn") }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "বাংলা",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (language == "bn") GamingDarkBg else TextSecondary
              )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (language == "en") NeonGreen else GamingDarkBg)
                .clickable { VpnRepository.setLanguage("en") }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "EN",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (language == "en") GamingDarkBg else TextSecondary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = GamingBorder)
        Spacer(modifier = Modifier.height(14.dp))

        // Kill Switch
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(imageVector = Icons.Default.Security, contentDescription = "Kill Switch", tint = NeonGreen, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (language == "bn") "কিল সুইচ (Kill Switch)" else "Kill Switch",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = if (language == "bn") "ভিপিএন ড্রপ হলে ইন্টারনেট ব্লক করবে" else "Block traffic if VPN disconnects",
                fontSize = 11.sp,
                color = TextMuted
              )
            }
          }

          Switch(
            checked = killSwitch,
            onCheckedChange = { VpnRepository.setKillSwitch(it) },
            colors = SwitchDefaults.colors(
              checkedThumbColor = NeonGreen,
              checkedTrackColor = NeonGreen.copy(alpha = 0.3f),
              uncheckedThumbColor = TextMuted,
              uncheckedTrackColor = GamingDarkBg
            )
          )
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = GamingBorder)
        Spacer(modifier = Modifier.height(14.dp))

        // Admin Access
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = "Admin", tint = GamingGold, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (language == "bn") "এডমিন ড্যাশবোর্ড" else "Admin Dashboard",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = if (language == "bn") "বিকাশ পেমেন্ট যাচাই ও সার্ভার কন্ট্রোল" else "bKash verification & server control",
                fontSize = 11.sp,
                color = TextMuted
              )
            }
          }

          Button(
            onClick = onNavigateToAdmin,
            colors = ButtonDefaults.buttonColors(containerColor = GamingCardElevated),
            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(GamingGold, GamingOrange))),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.height(32.dp)
          ) {
            Text(text = "Open", fontSize = 11.sp, color = GamingGold)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // About Box
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GamingDarkBg),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, GamingBorder)))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Info, contentDescription = "Info", tint = CyberCyan, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "FF VPN v1.0.0 (WireGuard Protocol)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = if (language == "bn")
            "বিশেষভাবে ফ্রি ফায়ার গেমারদের জন্য তৈরি। আল্ট্রা লো পিং, নিরাপদ ওয়্যারগার্ড এনক্রিপশন এবং ফাস্ট গেমিং রাউটিং নোড।"
          else
            "Engineered for Free Fire mobile gamers with ultra-low ping WireGuard routing and anti-congestion architecture.",
          fontSize = 11.sp,
          color = TextMuted,
          lineHeight = 16.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}
