package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionState
import com.example.model.VpnServer
import com.example.ui.Strings
import com.example.ui.components.PingBadge
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingDarkBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.GamingOrange
import com.example.ui.theme.GamingRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.VpnRepository

@Composable
fun ServerListScreen(
  vpnLauncher: ActivityResultLauncher<Intent>?,
  onNavigateToPremium: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val serverList by VpnRepository.serverList.collectAsState()
  val currentServer by VpnRepository.currentServer.collectAsState()
  val connectionState by VpnRepository.connectionState.collectAsState()
  val userAccount by VpnRepository.userAccount.collectAsState()
  val language by VpnRepository.language.collectAsState()

  var selectedTabIndex by remember { mutableIntStateOf(0) }
  var viewingWgServer by remember { mutableStateOf<VpnServer?>(null) }

  val tabs = listOf(
    if (language == "bn") "সকল সার্ভার" else "All Servers",
    if (language == "bn") "ফ্রি (${serverList.count { !it.isPremium }})" else "Free (${serverList.count { !it.isPremium }})",
    if (language == "bn") "ভিআইপি (${serverList.count { it.isPremium }})" else "VIP (${serverList.count { it.isPremium }})",
    if (language == "bn") "গেমিং লো-পিং" else "Gaming Low Ping"
  )

  val filteredServers = when (selectedTabIndex) {
    1 -> serverList.filter { !it.isPremium }
    2 -> serverList.filter { it.isPremium }
    3 -> serverList.filter { it.isGamingOptimized }.sortedBy { it.pingMs }
    else -> serverList
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = Strings.get("servers", language),
          fontSize = 20.sp,
          fontWeight = FontWeight.Black,
          color = TextPrimary
        )
        Text(
          text = if (language == "bn") "১০টি দেশের হাই-স্পিড ওয়্যারগার্ড নোড" else "10 Countries High-Speed WireGuard Nodes",
          fontSize = 12.sp,
          color = TextMuted
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Filter Tabs
    ScrollableTabRow(
      selectedTabIndex = selectedTabIndex,
      containerColor = GamingCardBg,
      contentColor = NeonGreen,
      edgePadding = 0.dp,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
          color = NeonGreen,
          height = 3.dp
        )
      },
      modifier = Modifier
        .clip(RoundedCornerShape(10.dp))
        .border(1.dp, GamingBorder, RoundedCornerShape(10.dp))
    ) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTabIndex == index,
          onClick = { selectedTabIndex = index },
          text = {
            Text(
              text = title,
              fontSize = 12.sp,
              fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
              color = if (selectedTabIndex == index) NeonGreen else TextSecondary
            )
          }
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Server List
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(filteredServers, key = { it.id }) { server ->
        val isSelected = currentServer.id == server.id
        val isLocked = server.isPremium && !userAccount.isPremium

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable {
              if (isLocked) {
                onNavigateToPremium()
              } else {
                VpnRepository.selectServer(server)
                if (connectionState == ConnectionState.CONNECTED) {
                  // Switch server
                  VpnRepository.startVpn(context, vpnLauncher)
                }
              }
            }
            .testTag("server_item_${server.id}"),
          colors = CardDefaults.cardColors(
            containerColor = if (isSelected) GamingCardBg.copy(alpha = 0.95f) else GamingCardBg
          ),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
              if (isSelected) listOf(NeonGreen, CyberCyan)
              else listOf(GamingBorder, GamingBorder)
            )
          )
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = server.flagEmoji, fontSize = 28.sp)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = if (language == "bn") server.nameBn else server.name,
                      fontSize = 15.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (server.isPremium) {
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(4.dp))
                          .background(GamingGold.copy(alpha = 0.2f))
                          .padding(horizontal = 5.dp, vertical = 2.dp)
                      ) {
                        Text(
                          text = "VIP",
                          fontSize = 9.sp,
                          fontWeight = FontWeight.Black,
                          color = GamingGold
                        )
                      }
                    } else {
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(4.dp))
                          .background(NeonGreen.copy(alpha = 0.15f))
                          .padding(horizontal = 5.dp, vertical = 2.dp)
                      ) {
                        Text(
                          text = "FREE",
                          fontSize = 9.sp,
                          fontWeight = FontWeight.Black,
                          color = NeonGreen
                        )
                      }
                    }
                  }
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = "${server.city} • IP: ${server.endpoint}",
                    fontSize = 11.sp,
                    color = TextMuted
                  )
                }
              }

              // Status and Ping
              Row(verticalAlignment = Alignment.CenterVertically) {
                PingBadge(pingMs = server.pingMs)
                Spacer(modifier = Modifier.width(8.dp))

                if (isLocked) {
                  Box(
                    modifier = Modifier
                      .size(32.dp)
                      .clip(CircleShape)
                      .background(GamingGold.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(
                      imageVector = Icons.Default.Lock,
                      contentDescription = "Locked",
                      tint = GamingGold,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                } else if (isSelected) {
                  Box(
                    modifier = Modifier
                      .size(32.dp)
                      .clip(CircleShape)
                      .background(NeonGreen.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = "Active",
                      tint = NeonGreen,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Load Progress & Action Footer
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "${Strings.get("load", language)}: ${server.loadPercent}%",
                  fontSize = 11.sp,
                  color = TextMuted
                )
                Spacer(modifier = Modifier.width(8.dp))
                LinearProgressIndicator(
                  progress = { server.loadPercent / 100f },
                  modifier = Modifier
                    .width(80.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp)),
                  color = if (server.loadPercent < 50) NeonGreen else GamingOrange,
                  trackColor = GamingDarkBg,
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                // View WireGuard config
                IconButton(
                  onClick = { viewingWgServer = server },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Code,
                    contentDescription = "WireGuard Config",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                  )
                }

                Spacer(modifier = Modifier.width(6.dp))

                if (isLocked) {
                  Button(
                    onClick = onNavigateToPremium,
                    colors = ButtonDefaults.buttonColors(containerColor = GamingGold),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(30.dp)
                  ) {
                    Text(
                      text = "Unlock",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = GamingDarkBg
                    )
                  }
                } else {
                  Button(
                    onClick = {
                      VpnRepository.selectServer(server)
                      VpnRepository.startVpn(context, vpnLauncher)
                    },
                    colors = ButtonDefaults.buttonColors(
                      containerColor = if (isSelected && connectionState == ConnectionState.CONNECTED) GamingRed else NeonGreen
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(30.dp)
                  ) {
                    Text(
                      text = if (isSelected && connectionState == ConnectionState.CONNECTED) "Disconnect" else "Connect",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = GamingDarkBg
                    )
                  }
                }
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  // WireGuard Config Dialog
  val currentViewingServer = viewingWgServer
  if (currentViewingServer != null) {
    AlertDialog(
      onDismissRequest = { viewingWgServer = null },
      confirmButton = {
        TextButton(onClick = { viewingWgServer = null }) {
          Text("Close", color = NeonGreen)
        }
      },
      containerColor = GamingCardBg,
      titleContentColor = TextPrimary,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(currentViewingServer.flagEmoji, fontSize = 20.sp)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "WireGuard Client Config", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column {
          Text(
            text = "Endpoint: ${currentViewingServer.endpoint}:${currentViewingServer.port}",
            fontSize = 12.sp,
            color = CyberCyan
          )
          Spacer(modifier = Modifier.height(6.dp))
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(GamingDarkBg)
              .padding(10.dp)
          ) {
            Text(
              text = currentViewingServer.generateWireGuardConfig(
                clientPrivateKey = "aGVsbG9mZnZwbndpcmVndWFyZHByaXZhdGVrZXkyMDI2PQ=="
              ),
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              color = TextPrimary
            )
          }
        }
      }
    )
  }
}
