package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionState
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.GamingBorder
import com.example.ui.theme.GamingCardBg
import com.example.ui.theme.GamingGold
import com.example.ui.theme.GamingOrange
import com.example.ui.theme.GamingRed
import com.example.ui.theme.GamingSurface
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GamingTopBar(
  lang: String,
  isAdmin: Boolean,
  onToggleLang: () -> Unit,
  onToggleAdmin: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(
            Brush.linearGradient(
              listOf(NeonGreen.copy(alpha = 0.2f), CyberCyan.copy(alpha = 0.1f))
            )
          )
          .border(1.dp, NeonGreen, RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Shield,
          contentDescription = "FF VPN",
          tint = NeonGreen,
          modifier = Modifier.size(26.dp)
        )
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "FF VPN",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.width(6.dp))
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(NeonGreen.copy(alpha = 0.15f))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "WIREGUARD",
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = NeonGreen
            )
          }
        }
        Text(
          text = if (lang == "bn") "ফ্রি ফায়ার আল্ট্রা লো পিং" else "Free Fire Ultra Low Ping",
          fontSize = 11.sp,
          color = TextMuted
        )
      }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
      // Language Toggle
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(GamingCardBg)
          .border(1.dp, GamingBorder, RoundedCornerShape(8.dp))
          .clickable { onToggleLang() }
          .padding(horizontal = 10.dp, vertical = 6.dp)
          .testTag("lang_toggle_button"),
        contentAlignment = Alignment.Center
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Language,
            contentDescription = "Language",
            tint = CyberCyan,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (lang == "bn") "বাংলা" else "EN",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      // Admin Panel toggle shortcut
      IconButton(
        onClick = onToggleAdmin,
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(if (isAdmin) NeonGreen.copy(alpha = 0.2f) else GamingCardBg)
          .border(
            1.dp,
            if (isAdmin) NeonGreen else GamingBorder,
            CircleShape
          )
          .testTag("admin_toggle_icon")
      ) {
        Icon(
          imageVector = Icons.Default.AdminPanelSettings,
          contentDescription = "Admin Panel",
          tint = if (isAdmin) NeonGreen else TextSecondary,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

@Composable
fun PingBadge(pingMs: Int, modifier: Modifier = Modifier) {
  val (bgColor, textColor) = when {
    pingMs <= 40 -> Pair(NeonGreen.copy(alpha = 0.15f), NeonGreen)
    pingMs <= 90 -> Pair(CyberCyan.copy(alpha = 0.15f), CyberCyan)
    pingMs <= 130 -> Pair(GamingOrange.copy(alpha = 0.15f), GamingOrange)
    else -> Pair(GamingRed.copy(alpha = 0.15f), GamingRed)
  }

  Row(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(bgColor)
      .padding(horizontal = 8.dp, vertical = 3.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(6.dp)
        .clip(CircleShape)
        .background(textColor)
    )
    Spacer(modifier = Modifier.width(5.dp))
    Text(
      text = "${pingMs}ms",
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold,
      color = textColor
    )
  }
}

@Composable
fun GamingStatCard(
  title: String,
  value: String,
  subtitle: String,
  icon: ImageVector,
  accentColor: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = GamingCardBg),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GamingBorder, accentColor.copy(alpha = 0.3f))))
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = title,
          fontSize = 12.sp,
          color = TextSecondary,
          fontWeight = FontWeight.Medium
        )
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = accentColor,
          modifier = Modifier.size(16.dp)
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        fontSize = 18.sp,
        fontWeight = FontWeight.ExtraBold,
        color = TextPrimary
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = subtitle,
        fontSize = 11.sp,
        color = TextMuted
      )
    }
  }
}
