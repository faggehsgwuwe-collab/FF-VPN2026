package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.model.ConnectionState
import com.example.model.TrafficStats
import com.example.model.VpnServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import kotlin.random.Random

class FfVpnService : VpnService() {

  companion object {
    const val ACTION_CONNECT = "com.ffvpn.app.ACTION_CONNECT"
    const val ACTION_DISCONNECT = "com.ffvpn.app.ACTION_DISCONNECT"
    const val EXTRA_SERVER_ID = "extra_server_id"
    private const val NOTIFICATION_ID = 7788
    private const val CHANNEL_ID = "ff_vpn_service_channel"
  }

  private var vpnInterface: ParcelFileDescriptor? = null
  private var serviceScope: CoroutineScope? = null
  private var monitorJob: Job? = null
  private var startTimeMs: Long = 0L

  override fun onCreate() {
    super.onCreate()
    createNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_CONNECT -> {
        val serverId = intent.getStringExtra(EXTRA_SERVER_ID)
        val server = VpnRepository.serverList.value.find { it.id == serverId }
          ?: VpnRepository.currentServer.value

        connectVpn(server)
      }
      ACTION_DISCONNECT -> {
        disconnectVpn()
      }
    }
    return START_NOT_STICKY
  }

  private fun connectVpn(server: VpnServer) {
    if (server.isPremium && !VpnRepository.userAccount.value.isPremium) {
      VpnRepository.setErrorMessage("প্রিমিয়াম সার্ভার ব্যবহার করতে প্রিমিয়াম সাবস্ক্রিপশন প্রয়োজন (Premium subscription required)")
      VpnRepository.updateConnectionState(ConnectionState.ERROR)
      return
    }

    VpnRepository.updateConnectionState(ConnectionState.CONNECTING)
    VpnRepository.setErrorMessage(null)

    serviceScope?.cancel()
    serviceScope = CoroutineScope(Dispatchers.Default)

    serviceScope?.launch {
      delay(800) // Brief connection handshake delay

      try {
        val builder = Builder()
          .setSession("FF VPN - ${server.name}")
          .setMtu(1420)
          .addAddress("10.200.0.2", 32)
          .addRoute("0.0.0.0", 0)
          .addDnsServer("1.1.1.1")
          .addDnsServer("8.8.8.8")

        vpnInterface = builder.establish()

        if (vpnInterface != null) {
          startTimeMs = System.currentTimeMillis()
          VpnRepository.updateConnectionState(ConnectionState.CONNECTED)
          startForeground(NOTIFICATION_ID, buildNotification(server, "Connected", "00:00"))
          startTrafficMonitor(server)
        } else {
          VpnRepository.setErrorMessage("VPN ইন্টারফেস তৈরি করা সম্ভব হয়নি (Failed to establish VPN interface)")
          VpnRepository.updateConnectionState(ConnectionState.ERROR)
          stopSelf()
        }
      } catch (e: Exception) {
        VpnRepository.setErrorMessage("VPN কানেকশন ত্রুটি: ${e.localizedMessage}")
        VpnRepository.updateConnectionState(ConnectionState.ERROR)
        stopSelf()
      }
    }
  }

  private fun startTrafficMonitor(server: VpnServer) {
    monitorJob?.cancel()
    monitorJob = serviceScope?.launch {
      var totalUp = 120_000L
      var totalDown = 450_000L
      val basePing = server.pingMs

      while (isActive) {
        delay(1000)
        val durationSec = (System.currentTimeMillis() - startTimeMs) / 1000

        // Realistic live simulation for game traffic
        val upDelta = (15_000L + Random.nextLong(20_000L))
        val downDelta = (45_000L + Random.nextLong(65_000L))
        totalUp += upDelta
        totalDown += downDelta

        val currentPing = (basePing + Random.nextInt(-3, 4)).coerceAtLeast(10)

        val stats = TrafficStats(
          uploadSpeedBps = upDelta,
          downloadSpeedBps = downDelta,
          totalBytesUploaded = totalUp,
          totalBytesDownloaded = totalDown,
          connectionDurationSeconds = durationSec,
          currentPingMs = currentPing
        )
        VpnRepository.updateTrafficStats(stats)

        // Update notification periodically
        if (durationSec % 3 == 0L) {
          val notification = buildNotification(server, "Ping: ${currentPing}ms", stats.formatDuration())
          val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
          notificationManager.notify(NOTIFICATION_ID, notification)
        }
      }
    }
  }

  private fun disconnectVpn() {
    VpnRepository.updateConnectionState(ConnectionState.DISCONNECTING)
    monitorJob?.cancel()
    serviceScope?.cancel()

    try {
      vpnInterface?.close()
      vpnInterface = null
    } catch (e: IOException) {
      e.printStackTrace()
    }

    VpnRepository.updateConnectionState(ConnectionState.DISCONNECTED)
    VpnRepository.updateTrafficStats(TrafficStats())

    stopForeground(STOP_FOREGROUND_REMOVE)
    stopSelf()
  }

  private fun buildNotification(server: VpnServer, statusText: String, durationText: String): Notification {
    val mainIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val contentPendingIntent = PendingIntent.getActivity(
      this, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val disconnectIntent = Intent(this, FfVpnService::class.java).apply {
      action = ACTION_DISCONNECT
    }
    val disconnectPendingIntent = PendingIntent.getService(
      this, 1, disconnectIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle("FF VPN: ${server.flagEmoji} ${server.name}")
      .setContentText("$statusText | $durationText")
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .setOngoing(true)
      .setContentIntent(contentPendingIntent)
      .addAction(
        android.R.drawable.ic_menu_close_clear_cancel,
        "Disconnect",
        disconnectPendingIntent
      )
      .build()
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "FF VPN Service",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Shows live FF VPN connection status and traffic stats"
      }
      val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      notificationManager.createNotificationChannel(channel)
    }
  }

  override fun onDestroy() {
    disconnectVpn()
    super.onDestroy()
  }
}
