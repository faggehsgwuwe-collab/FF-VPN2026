package com.example.model

data class PremiumRequest(
  val id: String,
  val userId: String,
  val userEmail: String,
  val transactionId: String,
  val amount: Int = 300,
  val paymentMethod: String = "bKash",
  val status: String = "PENDING", // PENDING, APPROVED, REJECTED
  val submittedAt: Long = System.currentTimeMillis(),
  val reviewedAt: Long? = null,
  val adminNote: String? = null
)

data class UserAccount(
  val uid: String,
  val email: String,
  val username: String,
  val isPremium: Boolean = false,
  val premiumExpiryDate: Long? = null,
  val isAdmin: Boolean = false
)
