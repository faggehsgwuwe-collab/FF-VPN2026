package com.example.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.activity.result.ActivityResultLauncher
import com.example.data.ServerDataSource
import com.example.model.ConnectionState
import com.example.model.PremiumRequest
import com.example.model.TrafficStats
import com.example.model.UserAccount
import com.example.model.VpnServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object VpnRepository {
  private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
  val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

  private val _currentServer = MutableStateFlow<VpnServer>(ServerDataSource.defaultServers[0])
  val currentServer: StateFlow<VpnServer> = _currentServer.asStateFlow()

  private val _trafficStats = MutableStateFlow(TrafficStats())
  val trafficStats: StateFlow<TrafficStats> = _trafficStats.asStateFlow()

  private val _serverList = MutableStateFlow<List<VpnServer>>(ServerDataSource.defaultServers)
  val serverList: StateFlow<List<VpnServer>> = _serverList.asStateFlow()

  private val _userAccount = MutableStateFlow(
    UserAccount(
      uid = "user_guest_017",
      email = "player@ffvpn.pro",
      username = "FreeFirePro",
      isPremium = false,
      isAdmin = false
    )
  )
  val userAccount: StateFlow<UserAccount> = _userAccount.asStateFlow()

  private val _premiumRequests = MutableStateFlow<List<PremiumRequest>>(
    listOf(
      PremiumRequest(
        id = "req_101",
        userId = "user_guest_017",
        userEmail = "player@ffvpn.pro",
        transactionId = "BL98AX7K2M",
        amount = 300,
        status = "PENDING",
        submittedAt = System.currentTimeMillis() - 3600000L
      )
    )
  )
  val premiumRequests: StateFlow<List<PremiumRequest>> = _premiumRequests.asStateFlow()

  private val _language = MutableStateFlow("bn") // "bn" or "en"
  val language: StateFlow<String> = _language.asStateFlow()

  private val _gamingModeEnabled = MutableStateFlow(true)
  val gamingModeEnabled: StateFlow<Boolean> = _gamingModeEnabled.asStateFlow()

  private val _selectedDns = MutableStateFlow("1.1.1.1 (Cloudflare Gaming)")
  val selectedDns: StateFlow<String> = _selectedDns.asStateFlow()

  private val _killSwitchEnabled = MutableStateFlow(false)
  val killSwitchEnabled: StateFlow<Boolean> = _killSwitchEnabled.asStateFlow()

  private val _errorMessage = MutableStateFlow<String?>(null)
  val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

  fun setLanguage(lang: String) {
    _language.value = lang
  }

  fun toggleGamingMode(enabled: Boolean) {
    _gamingModeEnabled.value = enabled
  }

  fun setDns(dns: String) {
    _selectedDns.value = dns
  }

  fun setKillSwitch(enabled: Boolean) {
    _killSwitchEnabled.value = enabled
  }

  fun selectServer(server: VpnServer) {
    _currentServer.value = server
  }

  fun updateConnectionState(state: ConnectionState) {
    _connectionState.value = state
  }

  fun updateTrafficStats(stats: TrafficStats) {
    _trafficStats.value = stats
  }

  fun setErrorMessage(msg: String?) {
    _errorMessage.value = msg
  }

  fun submitPremiumRequest(transactionId: String): Boolean {
    val trimmed = transactionId.trim().uppercase()
    if (trimmed.length < 8) return false

    val newReq = PremiumRequest(
      id = "req_" + System.currentTimeMillis().toString().takeLast(6),
      userId = _userAccount.value.uid,
      userEmail = _userAccount.value.email,
      transactionId = trimmed,
      amount = 300,
      status = "PENDING",
      submittedAt = System.currentTimeMillis()
    )
    _premiumRequests.value = listOf(newReq) + _premiumRequests.value
    return true
  }

  fun approvePremiumRequest(requestId: String) {
    val updated = _premiumRequests.value.map { req ->
      if (req.id == requestId) {
        req.copy(status = "APPROVED", reviewedAt = System.currentTimeMillis())
      } else req
    }
    _premiumRequests.value = updated

    // If matches current user, unlock premium
    val target = updated.find { it.id == requestId }
    if (target?.userId == _userAccount.value.uid) {
      _userAccount.value = _userAccount.value.copy(
        isPremium = true,
        premiumExpiryDate = System.currentTimeMillis() + 30L * 24 * 3600 * 1000L
      )
    }
  }

  fun rejectPremiumRequest(requestId: String, note: String = "Transaction verification failed") {
    _premiumRequests.value = _premiumRequests.value.map { req ->
      if (req.id == requestId) {
        req.copy(status = "REJECTED", reviewedAt = System.currentTimeMillis(), adminNote = note)
      } else req
    }
  }

  fun toggleAdminMode() {
    _userAccount.value = _userAccount.value.copy(isAdmin = !_userAccount.value.isAdmin)
  }

  fun toggleServerOnline(serverId: String) {
    _serverList.value = _serverList.value.map {
      if (it.id == serverId) it.copy(isOnline = !it.isOnline) else it
    }
    if (_currentServer.value.id == serverId) {
      _currentServer.value = _serverList.value.first { it.id == serverId }
    }
  }

  fun addServer(server: VpnServer) {
    _serverList.value = _serverList.value + server
  }

  fun startVpn(context: Context, vpnLauncher: ActivityResultLauncher<Intent>?) {
    val intent = VpnService.prepare(context)
    if (intent != null) {
      vpnLauncher?.launch(intent)
      return
    }

    val serviceIntent = Intent(context, FfVpnService::class.java).apply {
      action = FfVpnService.ACTION_CONNECT
      putExtra(FfVpnService.EXTRA_SERVER_ID, _currentServer.value.id)
    }
    context.startService(serviceIntent)
  }

  fun stopVpn(context: Context) {
    val serviceIntent = Intent(context, FfVpnService::class.java).apply {
      action = FfVpnService.ACTION_DISCONNECT
    }
    context.startService(serviceIntent)
  }
}
